﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TEST.COMport_Work1.Classes
{
    public struct FlashHardware
    {
        public uint ChipId;
        public uint ChipSize;
        public uint Total4kSectors;
    }

    public enum FlashTypes : uint
    {
        FLHW_W25Q32 = 0,
        FLHW_W25Q64 = 1,
        FLHW_W25Q128 = 2,
        FLHW_W25QUNKNOWN = 0xFF
    }

    public static class FlashManager
    {
        // Объявляем словарь
        public static readonly Dictionary<FlashTypes, FlashHardware> FlashTable = new Dictionary<FlashTypes, FlashHardware>();

        // Статический конструктор для VS2010 (.NET 4.0)
        static FlashManager()
        {
            // Наполняем таблицу старым надежным способом через .Add()
            FlashTable.Add(FlashTypes.FLHW_W25Q32, new FlashHardware { ChipId = 0x00EF4016, ChipSize = 16384, Total4kSectors = 1024 }); // W25Q32
            FlashTable.Add(FlashTypes.FLHW_W25Q64, new FlashHardware { ChipId = 0x00EF4017, ChipSize = 32768, Total4kSectors = 2048 }); // W25Q64
            FlashTable.Add(FlashTypes.FLHW_W25Q128, new FlashHardware { ChipId = 0x00EF4018, ChipSize = 65536, Total4kSectors = 4096 }); // W25Q128
        }

        public static FlashHardware GetFlashHw(FlashTypes fhwt)
        {
            if (FlashTable.ContainsKey(fhwt) == false) {

                FlashHardware res = new FlashHardware();
                res.ChipId = 0;
                res.ChipSize = 0;
                res.Total4kSectors = 0;

                return res;
            }

            return FlashTable[fhwt];
        }

        public static FlashTypes GetFlashHwID(uint ChipId)
        {
            // Бежим по всем элементам (KeyValuePair) нашего словаря
            foreach (KeyValuePair<FlashTypes, FlashHardware> pair in FlashTable)
            {
                // Если нашли структуру, у которой внутренний ChipId совпал с искомым
                if (pair.Value.ChipId == ChipId)
                {
                    return pair.Key; // Мгновенно возвращаем готовую структуру из таблицы
                }
            }

            // Если прокрутили весь цикл и ничего не нашли (левый чип)
            return FlashTypes.FLHW_W25QUNKNOWN;
        }
    }
}
