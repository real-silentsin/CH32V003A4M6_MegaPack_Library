﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TEST.COMport_Work1.Classes.TaskEngine
{
    // ----------------------------------------------------------------------------------------------------------------
    /// <summary>
    /// Задача удаления файла с указанным идентификатором
    /// </summary>
    public class ProtoDeleteFileActionClass : SimpleAction
    {
        // ------------------------------------------------------------------------------------------------------------
        public ProtoDeleteFileActionClass() { }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Конструктор класса
        /// </summary>
        public ProtoDeleteFileActionClass(byte Device)
        {
            this.device = Device;
        }
        // ------------------------------------------------------------------------------------------------------------
        public override string Description
        {
            get { return "Удаление файла с указанным ID"; }
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Индекс удаляемого файла
        /// </summary>
        private UInt16 file_idx = 0;
        // ------------------------------------------------------------------------------------------------------------
        private bool isOK = false;
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Индекс удаляемого файла
        /// </summary>
        public UInt16 FileID { get { return file_idx; } }
        // ------------------------------------------------------------------------------------------------------------
        public override bool Invoke(ProtoTargets.ProtoTarget Target, byte[] IncomingData)
        {
            return false;
        }
        // ------------------------------------------------------------------------------------------------------------
        public override void IncomingResponce(uint Code)
        {
            // Ожидаемые ответы
            // 235, 135

            switch (Code)
            {
                case FlashConst.FLASH_STATE_DELFILE_OK:

                    ErrorCode = FlashConst.FLASH_STATE_DELFILE_OK;
                    ThrowLogEvent(string.Format("Файл удалён: {0}", file_idx));

                    break;

                case FlashConst.FLASH_STATE_DELFILE_FAILED:

                    ErrorCode = FlashConst.FLASH_STATE_DELFILE_FAILED;
                    ThrowLogEvent(string.Format("Ошибка удаления файла: {0}", file_idx));

                    break;

                default: return;
            }

            Status = SimpleActionStatusTypes.Complete;
        }
        // ------------------------------------------------------------------------------------------------------------
        public override void Start()
        {
            if (Status == SimpleActionStatusTypes.Ready)
            {
                ProtoCMDPacket pcmd = new ProtoCMDPacket(0, this.device, FlashConst.FLASH_CMD_ERASE_FILE, file_idx);
                string cmd_str = pcmd.Create();

                if (string.IsNullOrEmpty(cmd_str) == false)
                {
                    ThrowSendDataEvent(cmd_str);
                }
                else
                {
                    ErrorCode = 300;
                    Status = SimpleActionStatusTypes.Error;

                    return;
                }
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        public override void Stop()
        {
            
        }
        // ------------------------------------------------------------------------------------------------------------
        public override bool SetProp<T>(string Name, T Value)
        {
            if (Status != SimpleActionStatusTypes.Stopped) { return false; }

            dynamic val = Value;
            //string val = (string)(object)Value;

            if (Utils.StringCompare(Name, "fileidx", false) == 0)
            {
                if ((Value is UInt16) == false) { return false; }

                file_idx = (UInt16)val;

                isOK = true;

                Status = SimpleActionStatusTypes.Ready;

                return true;
            }

            return false;
        }
        // ------------------------------------------------------------------------------------------------------------
        public override bool IsValid()
        {
            return isOK;
        }
        // ------------------------------------------------------------------------------------------------------------
        public override void Dispose()
        {
            
        }
        // ------------------------------------------------------------------------------------------------------------
    }
    // ----------------------------------------------------------------------------------------------------------------
}
