﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TEST.COMport_Work1.Classes.TaskEngine
{
    // ----------------------------------------------------------------------------------------------------------------
    /// <summary>
    /// Класс - аргумент для обработчиков события с указанием индекса
    /// </summary>
    public sealed class SimpleActionDoEventArgs : EventArgs
    {
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Конструктор класса по умолчанию
        /// </summary>
        /// <param name="Index">Индекс, сгенерировавший событие</param>
        public SimpleActionDoEventArgs() { }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Конструктор с параметрами
        /// </summary>
        /// <param name="PacketType">Тип исходящего пакета</param>
        /// <param name="OutgoingData">Индекс, сгенерировавший событие</param>
        public SimpleActionDoEventArgs(string OutgoingData) 
        {
            this.outgoingData = OutgoingData;
        }
        // ------------------------------------------------------------------------------------------------------------
        private string outgoingData = null;
        /// <summary>
        /// Индекс, сгенерировавший событие
        /// </summary>
        public string OutgoingData { get { return outgoingData; } }
        // ------------------------------------------------------------------------------------------------------------
    }
    // ----------------------------------------------------------------------------------------------------------------
}
