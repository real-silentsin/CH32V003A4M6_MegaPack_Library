﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace TEST.COMport_Work1.Classes.TaskEngine
{
    // ----------------------------------------------------------------------------------------------------------------
    /// <summary>
    /// Задача отправки файла в непрерывную область флеш-память
    /// </summary>
    public class TaskSendContFileClass : SimpleAction
    {
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Конструктор класса по умолчанию
        /// </summary>
        public TaskSendContFileClass() { }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Конструктор класса
        /// </summary>
        public TaskSendContFileClass(byte Device)
        {
            this.device = Device;
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Хранилище данных
        /// </summary>
        ProtoSimpleFileClass file_data;
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Отправленные данные
        /// </summary>
        private UInt32 total_sent = 0;
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Текущий отправляемый фрагмент
        /// </summary>
        private UInt16 current_page = 0;
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Флаг того, что был создан файл-заголовок
        /// </summary>
        private bool stubIsCreated = false;
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Новый адрес свободной области
        /// </summary>
        private UInt32 new_addr_freecont_area = UInt32.MaxValue;
        // ------------------------------------------------------------------------------------------------------------
        public override string Description
        {
            get { return "Задача отправки файла в непрерывную область флеш-памяти"; }
        }
        // ------------------------------------------------------------------------------------------------------------
        // Создание файла-заголовка в протокольной части флеши
        private void CreateFileStub()
        {
            if (stubIsCreated) { return; }

            Thread.Sleep(1000);

            ProtoHelper.FileRecordT header = new ProtoHelper.FileRecordT();
            header.Address = file_data.Address;
            header.Blocks = (ushort)file_data.Count;
            header.ID = file_data.ID;
            header.Size = file_data.FileLength;

            byte[] hdr_bin = XProtoSerializer.StructureToBytes(header);
            if (Utils.ArrayIsNullOrEmpty(hdr_bin))
            {
                message = "no header binary data0 <CreateFileStub>";
                ErrorCode = 515;

                ThrowErrorEvent();
                return;
            }

            file_data.Dispose();

            file_data = new ProtoSimpleFileClass(ProtoSimpleFileClass.DataTypes.XProto);
            file_data.ID = header.ID;

            file_data.Add(hdr_bin);

            byte[] page_data = file_data.GetProtoPage(0);
            if (Utils.ArrayIsNullOrEmpty(hdr_bin))
            {
                message = "no header binary data1 <CreateFileStub>";
                ErrorCode = 516;

                ThrowErrorEvent();
                return;
            }

            ProtoDataBINPacket binpack = new ProtoDataBINPacket(current_page, device, ProtoTargets.XP_FLASHPAGE_WRITE_PACKET);
            binpack.AddData(page_data);

            string result_proto_str = binpack.Create();

            if (string.IsNullOrEmpty(result_proto_str) == false)
            {
                stubIsCreated = true;
                ThrowSendDataEvent(result_proto_str);
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        // Отправка текущей страницы
        private bool SendCurrentPage()
        {
            byte[] page_data = file_data.GetProtoPage(current_page);
            if (Utils.ArrayIsNullOrEmpty(page_data)) 
            {
                if (current_page > 0 && stubIsCreated == false)
                {
                    CreateFileStub();
                    return true;
                }

                return false; 
            }

            Thread.Sleep(100);

            try
            {
                total_sent += (uint)file_data[current_page].Length;

                int progress = (int)((total_sent * 100) / file_data.FileLength);
                ThrowProgressEvent(progress);
            }
            catch { }

            ProtoDataBINPacket binpack = new ProtoDataBINPacket((UInt16)file_data.Address, device, ProtoTargets.XP_FLASHPAGE_CONTWRITE_PACKET);
            binpack.AddData(page_data);

            string result_proto_str = binpack.Create();

            if (string.IsNullOrEmpty(result_proto_str) == false)
            {
                current_page += 1;

                ThrowSendDataEvent(result_proto_str);
                return true;                
            }
            else
            {
                ErrorCode = 102;
                Status = SimpleActionStatusTypes.Error;
            }

            return false;
        }
        // ------------------------------------------------------------------------------------------------------------
        public override bool Invoke(ProtoTargets.ProtoTarget Target, byte[] IncomingData)
        {
            if (Target.Device != this.device) { return false; }
            if (Utils.ArrayIsNullOrEmpty(IncomingData)) { return false; }

            bool isPageData = false;

            switch (Target.PackIdent)
            {
                case ProtoTargets.XP_BINDATA_PACKET:

                    break;

                case ProtoTargets.XP_FLASHPAGE_READ_PACKET:

                    // Здесь пришли запрошенные данные (страница памяти)
                    isPageData = true;

                    break;

                default: return false;
            }

            byte _target = ProtoTargets.uart_createTarget2(Target);
            ProtoHelper.BINPacket? bin_pack = ProtoHelper.uart_decodeBinDataPacket(IncomingData, _target);

            if (bin_pack == null) { return false; }

            // Обработка пришедших данных - страница, 256 байт
            if (isPageData && bin_pack.Value.HeaderU32 == FlashConst.FLASH_PACK_FILECONTINFO)
            {

                ProtoHelper.FileRecordT file_info = XProtoSerializer.BytesToStructure<ProtoHelper.FileRecordT>(bin_pack.Value.Data);

                if (file_info.Address > 0 && file_info.Blocks == file_data.Count && file_info.ID == file_data.ID)
                {
                    // Получение начального сектора записи
                    file_data.Address = file_info.Address;
                    current_page = 0;

                    // Новый адрес свободной области
                    new_addr_freecont_area = file_info.Address + (UInt32)file_data.Count;

                    // Отправка запроса на установку адреса записи
                    ProtoCMDPacket pcmd = new ProtoCMDPacket(0, this.device, FlashConst.FLASH_CMD_SETWRITEADDR, file_data.Address);

                    string cmd_str = pcmd.Create();

                    if (string.IsNullOrEmpty(cmd_str) == false)
                    {
                        ThrowSendDataEvent(cmd_str);
                    }
                    else
                    {
                        ErrorCode = 300;
                        Status = SimpleActionStatusTypes.Error;

                        return false;
                    }

                    return true;
                }
                else
                {
                    // Сбой запроса!
                    file_data.Address = 0;
                    current_page = 0;

                    return false;
                }
            }
        
            return true;
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Копирование данных из внешнего набора
        /// </summary>
        /// <param name="Data">Набор данных</param>
        /// <returns></returns>
        public bool CopyData(ProtoSimpleFileClass Data, ProtoSimpleFileClass.DataTypes DataType)
        {
            if (Data == null || Data.Count == 0) { return false; }

            if (file_data == null)
            {
                file_data = new ProtoSimpleFileClass(DataType);
            }
            
            file_data.Clear();
            file_data.ID = Data.ID;

            for (int index = 0; index < Data.Count; index++)
            {
                byte[] data = Data[index];
                if (file_data.Copy(index, data) == false) { return false; }
            }

            return true;
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Реакция на события
        /// </summary>
        /// <param name="Code">Код события</param>
        public override void IncomingResponce(uint Code)
        {
            // 201 - OK, 104 - Fail
            if (Status != SimpleActionStatusTypes.Ready) { return; }

            // Инициализация. Запрос на существование файла.
            if (Code == 0)
            {
                // Проверка файла на существование
                // Возврат 137 (OK), 237 (Exists)
                ProtoCMDPacket pcmd = new ProtoCMDPacket(0, this.device, FlashConst.FLASH_CMD_GET_FILEEXISTSID, file_data.ID);

                string cmd_str = pcmd.Create();

                if (string.IsNullOrEmpty(cmd_str) == false)
                {
                    ThrowSendDataEvent(cmd_str);
                }
                else
                {
                    ErrorCode = 300;
                    Status = SimpleActionStatusTypes.Error;

                    return;
                }

                return;
            }

            // Такой файл уже существует?
            if (Code == FlashConst.FLASH_STATE_FILE_EXISTS)
            {
                ErrorCode = 105;
                message = "Файл с таким ID уже существует!";
                Status = SimpleActionStatusTypes.Error;

                return;
            }

            if (Code == FlashConst.FLASH_STATE_FILE_NOFOUND)
            {
                // Файла нет, ок, запрашиваем начальную страницу для записи в непрерывную область
                ProtoCMDPacket pcmd = new ProtoCMDPacket(0, this.device, FlashConst.FLASH_CMD_FINDCONTPLACE, file_data.ID, (uint)file_data.Count);

                string cmd_str = pcmd.Create();

                if (string.IsNullOrEmpty(cmd_str) == false)
                {
                    ThrowSendDataEvent(cmd_str);
                }
                else
                {
                    ErrorCode = 301;
                    Status = SimpleActionStatusTypes.Error;

                    return;
                }

                return;
            }

            // Адрес непрерывной записи успешно установлен!
            if (Code == FlashConst.FLASH_STATE_SETWRITEADDR_OK)
            {
                // Можно начинать закачку файла
                if (SendCurrentPage() == false)
                {
                    ErrorCode = 510;
                    Status = SimpleActionStatusTypes.Error;
                }

                return;
            }

            // Адрес непрерывной записи не принимается
            if (Code == FlashConst.FLASH_STATE_SETWRITEADDR_FAILED)
            {
                ErrorCode = FlashConst.FLASH_STATE_SETWRITEADDR_FAILED;
                Status = SimpleActionStatusTypes.Error;

                return;
            }

            // Предыдущая запись обломилась?
            if (Code == FlashConst.FLASH_STATE_WRITECONTADDR_FAILED)
            {
                ErrorCode = Code;
                Status = SimpleActionStatusTypes.Error;

                return;
            }

            // Успешное сохранение отправленной ранее страницы
            if (Code == FlashConst.FLASH_STATE_WRITECONTADDR_OK)
            {
                // Запрос следующей записи
                SendCurrentPage();

                return;
            }

            // Файл-заголовок успешно создан!
            if (Code == FlashConst.FLASH_STATE_WRPAGE_OK)
            {
                // Сохранение файла в общем завершено, теперь нужно поправить адрес свободной области
                if (new_addr_freecont_area < UInt32.MaxValue)
                {
                    // Запрос на сохранение нового адреса свободного пространства непрерывной области памяти
                    ProtoCMDPacket pcmd = new ProtoCMDPacket(0, this.device, FlashConst.FLASH_CMD_SETNEW_FREECONTAREA, new_addr_freecont_area, 0);

                    string cmd_str = pcmd.Create();

                    if (string.IsNullOrEmpty(cmd_str) == false)
                    {
                        ThrowSendDataEvent(cmd_str);
                    }
                    else
                    {
                        ErrorCode = 301;
                        Status = SimpleActionStatusTypes.Error;

                        return;
                    }

                    return;
                }

                return;
            }

            // Установили новый адрес начала свободной части непрерывной области
            if (Code == FlashConst.FLASH_STATE_SET_FREECONTAREA_OK)
            {
                message = "Файл успешно отправлен!";
                ErrorCode = 200;
                Status = SimpleActionStatusTypes.Complete;

                return;
            }

            // Новый адрес начала свободной части непрерывной области не записан!
            if (Code == FlashConst.FLASH_STATE_SET_FREECONTAREA_FAILED)
            {
                message = "Файл успешно отправлен! Но новый адрес не сохранен!";
                ErrorCode = 210;
                Status = SimpleActionStatusTypes.Complete;

                return;
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        public override void Start()
        {
            if (Status == SimpleActionStatusTypes.Stopped)
            {
                if (file_data == null || file_data.IsValid(true) == false)
                {
                    ErrorCode = 104;
                    Status = SimpleActionStatusTypes.Error;

                    return;
                }

                Status = SimpleActionStatusTypes.Ready;

                total_sent = 0;
                stubIsCreated = false;

                IncomingResponce(0);
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        public override void Stop()
        {
            Status = SimpleActionStatusTypes.Stopped;
        }
        // ------------------------------------------------------------------------------------------------------------
        public override bool SetProp<T>(string Name, T Value)
        {
            if (Status != SimpleActionStatusTypes.Stopped) { return false; }

            dynamic val = Value;
            //string val = (string)(object)Value;

            if (Utils.StringCompare(Name, "loadfile", false) == 0)
            {
                if ((Value is string) == false) { return false; }

                file_data.Clear();

                if (file_data.Load((string)val))
                {
                    file_data.Address = 0;
                    Status = SimpleActionStatusTypes.Ready;

                    return true;
                }
            }

            if (Utils.StringCompare(Name, "fileid", false) == 0)
            {
                if ((Value is UInt16) == false) { return false; }

                file_data.ID = (UInt16)val;

                return true;
            }

            if (Utils.StringCompare(Name, "tilevalue", false) == 0)
            {
                if ((Value is byte) == false) { return false; }

                file_data.TileCode = (byte)val;

                return true;
            }

            if (Utils.StringCompare(Name, "expand", false) == 0)
            {
                if ((Value is bool) == false) { return false; }

                file_data.ExpandPages = (bool)val;

                return true;
            }

            return false;
        }
        // ------------------------------------------------------------------------------------------------------------
        public override void Dispose()
        {
            Status = SimpleActionStatusTypes.Unknown;
        }
        // ------------------------------------------------------------------------------------------------------------
        public override bool IsValid()
        {
            return (file_data.Count > 0);
        }
        // ------------------------------------------------------------------------------------------------------------
    }
    // ----------------------------------------------------------------------------------------------------------------
}
