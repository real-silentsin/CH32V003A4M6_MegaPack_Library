﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace TEST.COMport_Work1.Classes.TaskEngine
{
    // ----------------------------------------------------------------------------------------------------------------
    /// <summary>
    /// Задача отправки файла во флеш-память
    /// </summary>
    public class TaskSendFileClass : SimpleAction
    {
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Конструктор класса по умолчанию
        /// </summary>
        public TaskSendFileClass() { }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Конструктор класса
        /// </summary>
        public TaskSendFileClass(byte Device)
        {
            this.device = Device;
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Хранилище данных
        /// </summary>
        ProtoSimpleFileClass file_data;
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Текущий сектор для отправки
        /// </summary>
        private UInt16 current_page = 0;
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Отправленные данные
        /// </summary>
        private UInt32 total_sent = 0;
        // ------------------------------------------------------------------------------------------------------------
        public override string Description
        {
            get { return "Задача отправки файла во влеш-память"; }
        }
        // ------------------------------------------------------------------------------------------------------------
        public override bool Invoke(ProtoTargets.ProtoTarget Target, byte[] IncomingData)
        {
            return true;
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Копирование данных из внешнего набора
        /// </summary>
        /// <param name="Data">Набор данных</param>
        /// <returns></returns>
        public bool CopyData(ProtoSimpleFileClass Data, ProtoSimpleFileClass.DataTypes DataType)
        {
            if (Data == null || Data.Count == 0) { return false; }

            if (file_data == null)
            {
                file_data = new ProtoSimpleFileClass(DataType);
            }
            
            file_data.Clear();
            file_data.ID = Data.ID;

            for (int index = 0; index < Data.Count; index++)
            {
                byte[] data = Data[index];
                if (file_data.Copy(index, data) == false) { return false; }
            }

            return true;
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Реакция на события
        /// </summary>
        /// <param name="Code">Код события</param>
        public override void IncomingResponce(uint Code)
        {
            // 201 - OK, 104 - Fail
            if (Status != SimpleActionStatusTypes.Ready) { return; }

            // Инициализация. Запрос на существование файла.
            if (Code == 0)
            {
                // Проверка файла на существование
                ProtoCMDPacket pcmd = new ProtoCMDPacket(0, this.device, FlashConst.FLASH_CMD_GET_FILEEXISTSID, file_data.ID);

                string cmd_str = pcmd.Create();

                if (string.IsNullOrEmpty(cmd_str) == false)
                {
                    ThrowSendDataEvent(cmd_str);
                }
                else
                {
                    ErrorCode = 300;
                    Status = SimpleActionStatusTypes.Error;

                    return;
                }

                return;
            }

            byte[] page_data = file_data.GetProtoPage(current_page);

            if (Utils.ArrayIsNullOrEmpty(page_data))
            {
                ErrorCode = 101;
                message = "Данных для отправки не предоставлено...";
                Status = SimpleActionStatusTypes.Error;

                return;
            }

            if (Code == 104)
            {
                ErrorCode = 104;
                Status = SimpleActionStatusTypes.Error;

                return;
            }

            // Такой файл уже существует?
            if (Code == FlashConst.FLASH_STATE_FILE_EXISTS)
            {
                ErrorCode = 105;
                message = "Файл с таким ID уже существует!";
                Status = SimpleActionStatusTypes.Error;

                return;
            }

            if (Code == FlashConst.FLASH_STATE_FILE_NOFOUND)
            {
                Code = FlashConst.FLASH_STATE_WRPAGE_OK;
            }

            // Предыдущая запись обломилась?
            if (Code != FlashConst.FLASH_STATE_WRPAGE_OK)
            {
                ErrorCode = Code;
                Status = SimpleActionStatusTypes.Error;

                return;
            }

            Thread.Sleep(30);

            try
            {
                total_sent += (uint)file_data[current_page].Length;

                int progress = (int)((total_sent * 100) / file_data.FileLength);
                ThrowProgressEvent(progress);
            }
            catch { }

            ProtoDataBINPacket binpack = new ProtoDataBINPacket(current_page, device, ProtoTargets.XP_FLASHPAGE_WRITE_PACKET);
            binpack.AddData(page_data);

            string result_proto_str = binpack.Create();

            if (string.IsNullOrEmpty(result_proto_str) == false)
            {
                ThrowSendDataEvent(result_proto_str);

                //string log_msg = string.Format("CRC: 0x{0:X2}, L: {1}, T:0x{2:X2}", binpack.Header.CRC8, binpack.Header.Length, binpack.Header.Target);
                //ThrowLogEvent(log_msg);

                current_page += 1;
                if (current_page < file_data.Count)
                {
                    Status = SimpleActionStatusTypes.Ready;
                }
                else
                {
                    message = "File are succesfull sent...";
                    ThrowCompleteEvent();

                    Status = SimpleActionStatusTypes.Complete;
                }
            }
            else
            {
                ErrorCode = 102;
                Status = SimpleActionStatusTypes.Error;
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        public override void Start()
        {
            if (Status == SimpleActionStatusTypes.Stopped)
            {
                if (file_data == null || file_data.IsValid(true) == false)
                {
                    ErrorCode = 104;
                    Status = SimpleActionStatusTypes.Error;

                    return;
                }

                Status = SimpleActionStatusTypes.Ready;

                total_sent = 0;
                IncomingResponce(0);
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        public override void Stop()
        {
            Status = SimpleActionStatusTypes.Stopped;
        }
        // ------------------------------------------------------------------------------------------------------------
        public override bool SetProp<T>(string Name, T Value)
        {
            if (Status != SimpleActionStatusTypes.Stopped) { return false; }

            dynamic val = Value;
            //string val = (string)(object)Value;

            if (Utils.StringCompare(Name, "loadfile", false) == 0)
            {
                if ((Value is string) == false) { return false; }

                file_data.Clear();

                if (file_data.Load((string)val))
                {
                    current_page = 0;
                    Status = SimpleActionStatusTypes.Ready;

                    return true;
                }
            }

            if (Utils.StringCompare(Name, "fileid", false) == 0)
            {
                if ((Value is UInt16) == false) { return false; }

                file_data.ID = (UInt16)val;

                return true;
            }

            return false;
        }
        // ------------------------------------------------------------------------------------------------------------
        public override void Dispose()
        {
            Status = SimpleActionStatusTypes.Unknown;
        }
        // ------------------------------------------------------------------------------------------------------------
        public override bool IsValid()
        {
            return (file_data.Count > 0);
        }
        // ------------------------------------------------------------------------------------------------------------
    }
    // ----------------------------------------------------------------------------------------------------------------
}
