﻿
namespace TEST.COMport_Work1
{
    public static class CRC8_Class
    {
        // --------------------------------------------------------------------
        public static byte crc8_update(byte crc, byte data)
        {
            crc ^= data;

            for (int i = 0; i < 8; i++)
            {
                if ((crc & 0x80) != 0)
                {
                    crc = (byte)((crc << 1) ^ 0x07);  // 0x07 — полином
                }
                else
                {
                    crc <<= 1;
                }
            }

            return crc;
        }
        // --------------------------------------------------------------------
        public static byte crc8_calculate(byte[] data, uint len) {

            byte crc = 0x00;  // Начальное значение (Init)
    
            for (int i = 0; i < len; i++) {
        
                crc = crc8_update (crc, data[i]);
            }

            return crc;
        }
        // --------------------------------------------------------------------
    }
}
