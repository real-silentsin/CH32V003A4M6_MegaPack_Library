﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TEST.COMport_Work1
{
    // --------------------------------------------------------------------------------------------
    /// <summary>
    /// Класс, представляющий командный пакет
    /// </summary>
    public class ProtoCMDPacket
    {
        protected ProtoCMDPacket() { }

        /// <summary>
        /// Конструктор класса по умолчанию
        /// </summary>
        /// <param name="pack_ident">Идентификатор CMD пакета</param>
        public ProtoCMDPacket(UInt16 pack_ident)
        {
            _header = new ProtoHelper.ProtoHeader();
            _header.MagicByte = ProtoHelper.UART_PROTO_MAGICBYTE;
            _pack_ident = pack_ident;

            _target.PackIdent = ProtoTargets.XP_CMD_PACKET;
        }

        public ProtoCMDPacket(UInt16 pack_ident, byte device) : this(pack_ident)
        {
            _target.Device = device;
        }

        public ProtoCMDPacket(UInt16 pack_ident, byte device, UInt16 cmd) : this(pack_ident, device)
        {
            _cmd = cmd;
        }

        public ProtoCMDPacket(UInt16 pack_ident, byte device, UInt16 cmd, UInt32 param) : this(pack_ident, device, cmd)
        {
            _param = param;
        }

        public ProtoCMDPacket(UInt16 pack_ident, byte device, UInt16 cmd, UInt32 param, UInt32 ext_param) : this(pack_ident, device, cmd, param)
        {
            _ext_param = ext_param;
        }

        private ProtoHelper.ProtoHeader _header;

        /// <summary>
        /// Доступ к заголовку XProto пакета
        /// </summary>
        public ProtoHelper.ProtoHeader Header { get { return _header; } }

        private UInt16 _pack_ident = 0;

        /// <summary>
        /// Идентификатор пакета
        /// </summary>
        public UInt16 Pack_Ident { get { return _pack_ident; } set { _pack_ident = value; } }

        private ProtoTargets.ProtoTarget _target = new ProtoTargets.ProtoTarget();

        /// <summary>
        /// Назначение пакета: устройство
        /// </summary>
        public byte TargetDevice 
        {
            get { return _target.Device; }
            set { _target.Device = value; }
        }

        private UInt16 _cmd = 0;

        /// <summary>
        /// Команда
        /// </summary>
        public UInt16 CMD { get { return _cmd; } set { _cmd = value; } }

        private UInt32 _param = 0;

        /// <summary>
        /// Параметр команды
        /// </summary>
        public UInt32 Param { get { return _param; } set { _param = value; } }

        private UInt32 _ext_param = 0;

        /// <summary>
        /// Дополнительный параметр
        /// </summary>
        public UInt32 Ext_param { get { return _ext_param; } set { _ext_param = value; } }

        /// <summary>
        /// Создание строкового представления командного пакета для передачи
        /// </summary>
        /// <returns>Строка или null</returns>
        public string Create()
        {
            return ProtoHelper.uart_createCMDPacketStr(_pack_ident, _cmd, _param, _ext_param, _target, out _header);
        }
    }
    // --------------------------------------------------------------------------------------------
}
