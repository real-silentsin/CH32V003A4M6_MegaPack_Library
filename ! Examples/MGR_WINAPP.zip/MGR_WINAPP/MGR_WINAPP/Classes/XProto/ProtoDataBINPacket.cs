﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TEST.COMport_Work1
{
    // --------------------------------------------------------------------------------------------
    /// <summary>
    /// Класс, представляющий пакет Data BIN
    /// </summary>
    public class ProtoDataBINPacket
    {
        protected ProtoDataBINPacket() { }

        /// <summary>
        /// Конструктор класса по умолчанию
        /// </summary>
        /// <param name="pack_ident">Идентификатор BIN пакета</param>
        public ProtoDataBINPacket(UInt16 pack_ident)
        {
            _header = new ProtoHelper.ProtoHeader();
            _header.MagicByte = ProtoHelper.UART_PROTO_MAGICBYTE;
            _pack_ident = pack_ident;

            _target.PackIdent = ProtoTargets.XP_BINDATA_PACKET;
        }

        public ProtoDataBINPacket(UInt16 pack_ident, byte device) : this(pack_ident)
        {
            _target.Device = device;
        }

        public ProtoDataBINPacket(UInt16 pack_ident, byte device, byte target_ident) : this(pack_ident, device)
        {
            _target.Device = device;
            _target.PackIdent = target_ident;
        }

        private ProtoHelper.ProtoHeader _header;

        /// <summary>
        /// Доступ к заголовку XProto пакета
        /// </summary>
        public ProtoHelper.ProtoHeader Header { get { return _header; } }

        private UInt16 _pack_ident = 0;

        /// <summary>
        /// Идентификатор BIN пакета
        /// </summary>
        public UInt16 Pack_Ident { get { return _pack_ident; } set { _pack_ident = value; } }

        private ProtoTargets.ProtoTarget _target = new ProtoTargets.ProtoTarget();

        /// <summary>
        /// Назначение пакета: устройство
        /// </summary>
        public byte TargetDevice 
        {
            get { return _target.Device; }
            set { _target.Device = value; }
        }

        /// <summary>
        /// Назначение пакета: тип пакета
        /// </summary>
        public byte TargetIdent
        {
            get { return _target.PackIdent; }
            set { _target.PackIdent = value; }
        }

        private List<byte> _data = new List<byte>();

        public void AddDataByte(byte data)
        {
            _data.Add(data);
        }

        public UInt16 AddData(byte[] data)
        {
            if (Utils.ArrayIsNullOrEmpty(data))
            {
                return 0;
            }

            if (data.Length <= ProtoHelper.UART_PROTO_MAX_BIN_DATA_SIZE)
            {
                _data.AddRange(data);
                return (UInt16)data.Length;
            }

            return 0;
        }

        public UInt16 Count { get { return (UInt16)_data.Count; } }

        public void Clear() { _data.Clear(); }

        public string Create()
        {
            if (_data.Count == 0) { return null; }

            return ProtoHelper.uart_createBinDataPacketStr(_data.ToArray(), _pack_ident, _target, out _header);
        }
    }
    // --------------------------------------------------------------------------------------------
}
