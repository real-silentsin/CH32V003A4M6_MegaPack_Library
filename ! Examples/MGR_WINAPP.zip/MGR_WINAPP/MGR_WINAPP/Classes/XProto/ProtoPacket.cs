﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TEST.COMport_Work1
{
    // --------------------------------------------------------------------------------------------
    /// <summary>
    /// Класс, представляющий простой пакет
    /// </summary>
    public class ProtoPacket
    {
        protected ProtoPacket() { }

        /// <summary>
        /// Конструктор класса по умолчанию
        /// </summary>
        /// <param name="target_ident">Идентификатор пакета</param>
        public ProtoPacket(byte target_ident)
        {
            _header = new ProtoHelper.ProtoHeader();
            _header.MagicByte = ProtoHelper.UART_PROTO_MAGICBYTE;

            _target.PackIdent = target_ident;
        }

        public ProtoPacket(byte target_ident, byte device) : this(target_ident)
        {
            _target.Device = device;
        }

        private ProtoHelper.ProtoHeader _header;

        /// <summary>
        /// Доступ к заголовку XProto пакета
        /// </summary>
        public ProtoHelper.ProtoHeader Header { get { return _header; } }

        private ProtoTargets.ProtoTarget _target = new ProtoTargets.ProtoTarget();

        /// <summary>
        /// Назначение пакета: устройство
        /// </summary>
        public byte TargetDevice 
        {
            get { return _target.Device; }
            set { _target.Device = value; }
        }

        /// <summary>
        /// Назначение пакета: тип пакета
        /// </summary>
        public byte TargetIdent
        {
            get { return _target.PackIdent; }
            set { _target.PackIdent = value; }
        }

        private List<byte> _data = new List<byte>();
        
        public UInt16 AddData(byte[] data)
        {
            _data.Clear();

            if (Utils.ArrayIsNullOrEmpty(data))
            {
                return 0;
            }

            if (data.Length <= ProtoHelper.UART_PROTO_MAX_DATA_SIZE)
            {
                _data.AddRange(data);
                return (UInt16)data.Length;
            }

            return 0;
        }

        public UInt16 Count { get { return (UInt16)_data.Count; } }

        public void Clear() { _data.Clear(); }

        public string Create()
        {
            if (_data.Count == 0) { return null; }

            _header.Length = (UInt16)_data.Count;
            _header.CRC8 = CRC8_Class.crc8_calculate(_data.ToArray(), _header.Length);
            _header.Target = ProtoTargets.uart_createTarget2(_target);

            return ProtoHelper.uart_createProtoPacket(_data.ToArray(), _header);
        }
    }
    // --------------------------------------------------------------------------------------------
}
