﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace TEST.COMport_Work1.Classes
{
    // --------------------------------------------------------------------------------------------
    /// <summary>
    /// Класс, представляющий отдельный файл протокола Flash/X
    /// </summary>
    public sealed class ProtoSimpleFileClass : IDisposable
    {
        // ----------------------------------------------------------------------------------------
        /// <summary>
        /// Конструктор класса по умолчанию
        /// </summary>
        private ProtoSimpleFileClass()
        {
            //sector_indexer = 0;
            file_length = 0;
        }
        // ----------------------------------------------------------------------------------------
        /// <summary>
        /// Конструктор класса с параметрами
        /// </summary>
        /// <param name="DataType">Тип данных</param>
        public ProtoSimpleFileClass(DataTypes DataType)
        {
            file_length = 0;
            dataType = DataType;
        }
        // ----------------------------------------------------------------------------------------
        /// <summary>
        /// Типы хранимых данных
        /// </summary>
        public enum DataTypes
        {
            /// <summary>
            /// Данные протокола X
            /// </summary>
            XProto,
            /// <summary>
            /// Просто бинарный файл
            /// </summary>
            Binary
        }
        // ----------------------------------------------------------------------------------------
        /// <summary>
        /// Максимальный размер файла
        /// </summary>
        public const int MAX_FILE_SIZE = 1045800; //(4200 страниц * 249 байт)
        // ----------------------------------------------------------------------------------------
        /// <summary>
        /// Максимальный размер порции данных на страницу
        /// </summary>
        public const int MAX_DATA_PER_PAGE = 249;
        // ----------------------------------------------------------------------------------------
        /// <summary>
        /// Максимальное количество страниц ля одного файла
        /// </summary>
        public const int MAX_PAGE_COUNT = 4200;
        // ----------------------------------------------------------------------------------------
        /// <summary>
        /// Хранилище данных
        /// </summary>
        private Dictionary<int, List<byte>> file_data = new Dictionary<int, List<byte>>();
        // ----------------------------------------------------------------------------------------
        /// <summary>
        /// Индекс для выдачи секторам
        /// </summary>
        //private int sector_indexer = 0;
        // ----------------------------------------------------------------------------------------
        /// <summary>
        /// Текущий формат хранимых данных
        /// </summary>
        private DataTypes dataType = DataTypes.XProto;
        // ----------------------------------------------------------------------------------------
        /// <summary>
        /// Текущий формат хранимых данных
        /// </summary>
        public DataTypes DataType { get { return dataType; } }
        // ----------------------------------------------------------------------------------------
        /// <summary>
        /// Длина файла в байтах
        /// </summary>
        private int file_length = 0;
        // ----------------------------------------------------------------------------------------
        /// <summary>
        /// Уникальный идентификатор файла
        /// </summary>
        private UInt16 file_id = 0;
        // ----------------------------------------------------------------------------------------
        /// <summary>
        /// Индекс для доступа к данным по номерам секторов файла
        /// </summary>
        /// <param name="Index"></param>
        /// <returns></returns>
        public byte[] this[int Index]
        {
            get
            {
                if (file_data.ContainsKey(Index))
                {
                    if (dataType == DataTypes.XProto)
                    {
                        return file_data[Index].ToArray();
                    }

                    if (dataType == DataTypes.Binary)
                    {
                        if (expandPages)
                        {
                            return Utils.TailedArray(file_data[Index].ToArray(), tileCode, 256);
                        }
                        else
                        {
                            return file_data[Index].ToArray();
                        }
                    }
                }

                return null;
            }
        }
        // ----------------------------------------------------------------------------------------
        private UInt32 address = 0;
        // ----------------------------------------------------------------------------------------
        /// <summary>
        /// Начальный адрес
        /// </summary>
        public UInt32 Address { get { return address; } set { address = value; } }
        // ----------------------------------------------------------------------------------------
        /// <summary>
        /// Уникальный идентификатор файла (ака имя фафла)
        /// </summary>
        public UInt16 ID
        {
            get { return file_id; }
            set { file_id = value; }
        }
        // ----------------------------------------------------------------------------------------
        /// <summary>
        /// Размер файла в байтах
        /// </summary>
        public uint FileLength { get { return GetFileLength(); } }
        // ----------------------------------------------------------------------------------------
        private byte tileCode = 0xFF;
        /// <summary>
        /// Код дополняющие неполные страницы (по умолчанию 0xFF) только для режима "Binary"
        /// </summary>
        public byte TileCode { get { return tileCode; } set { tileCode = value; } }
        // ----------------------------------------------------------------------------------------
        private bool expandPages = false;
        /// <summary>
        /// Автоматически расширять размеры страницы, если они меньше 256 байт значением TileCode
        /// </summary>
        public bool ExpandPages { get { return expandPages; } set { expandPages = value; } }
        // ----------------------------------------------------------------------------------------
        /// <summary>
        /// Получить последний индекс
        /// </summary>
        public int MaxPageIndex
        {
            get
            {
                try
                {
                    return file_data.Keys.Max();
                }
                catch { }

                return -1;
            }
        }
        // ----------------------------------------------------------------------------------------
        /// <summary>
        /// Получить размер всех загруженных данных объекта
        /// </summary>
        /// <returns>Размер данных в байтах</returns>
        private uint GetFileLength()
        {
            if (file_data.Count == 0) { return 0; }

            uint file_length = 0;

            foreach (var item in file_data)
            {
                try
                {
                    file_length += (uint)item.Value.Count;
                }
                catch { }
            }

            return file_length;
        }
        // ----------------------------------------------------------------------------------------
        /// <summary>
        /// Добавить новую страницу
        /// </summary>
        /// <param name="page_data">Данные страницы (до 249 байт)</param>
        /// <returns>Оценка успешности операции</returns>
        public bool Add(byte[] page_data)
        {
            if (Utils.ArrayIsNullOrEmpty(page_data) || page_data.Length == 0 || page_data.Length > 256) { return false; }
            if (file_data.Count < MAX_PAGE_COUNT)
            {
                List<byte> newdata = new List<byte>(page_data);
                
                int max_index = MaxPageIndex;
                
                if (max_index < MAX_PAGE_COUNT)
                {
                    file_data.Add(max_index + 1, newdata);
                    file_length += newdata.Count;

                    return true;
                }
            }

            return false;
        }
        // ----------------------------------------------------------------------------------------
        /// <summary>
        /// Копирование данных из внешнего источника
        /// </summary>
        /// <param name="Key">Индекс записи</param>
        /// <param name="value">Данные записи</param>
        /// <returns>Оценка успешности операции</returns>
        public bool Copy(int Key, byte[] value)
        {
            if (Utils.ArrayIsNullOrEmpty(value)) { return false; }
            if (value.Length > 256) { return false; }
            if (file_data.ContainsKey(Key)) { return false; }

            file_data.Add(Key, new List<byte>(value));

            return true;
        }
        // ----------------------------------------------------------------------------------------
        /// <summary>
        /// Замена данных по указанному индексу
        /// </summary>
        /// <param name="Key">Индекс записи</param>
        /// <param name="value">Данные записи</param>
        /// <param name="RemoveXHeader">Удалить X заголовок</param>
        /// <returns>Оценка успешности операции</returns>
        public bool Accept(int Key, byte[] value, bool RemoveXHeader)
        {
            if (Utils.ArrayIsNullOrEmpty(value) || file_data.ContainsKey(Key) == false) { return false; }
            if (value.Length > 256 || value.Length < 7) { return false; }

            List<byte> tmp_data = new List<byte>(value);

            //List<byte> tmp_data = Utils.TailedArray2(value, tileCode, 256);

            if (dataType == DataTypes.XProto && RemoveXHeader)
            {
                tmp_data.RemoveRange(0, ProtoHelper.XPROTO_PAGE_HEADER_SIZE);
            }

            file_data.Remove(Key);
            file_data.Add(Key, tmp_data);

            return true;
        }
        // ----------------------------------------------------------------------------------------
        /// <summary>
        /// Количество секторов файла
        /// </summary>
        public int Count { get { return file_data.Count; } }
        // ----------------------------------------------------------------------------------------
        /// <summary>
        /// Проверка, валидные ли данные в хранилище
        /// </summary>
        public bool IsValid(bool useID)
        {
            if (file_data.Count == 0 || file_data.Count >= MAX_PAGE_COUNT) { return false; }
            if (useID && file_id == 0) { return false; }

            int last_index = MaxPageIndex;

            foreach (KeyValuePair<int, List<byte>> pair in file_data)
            {
                if (pair.Key == last_index) { continue; }
                if (dataType == DataTypes.XProto)
                {
                    if (pair.Value.Count != MAX_DATA_PER_PAGE) { return false; }
                }
                else
                {
                    if (pair.Value.Count != 256) { return false; }
                }
            }

            return true;
        }
        // ----------------------------------------------------------------------------------------
        /// <summary>
        /// Очистка данных
        /// </summary>
        public void Clear()
        {
            file_data.Clear();
            //sector_indexer = 0;
            file_length = 0;
            address = 0;
        }
        // ----------------------------------------------------------------------------------------
        /// <summary>
        /// Загрузка данных из файла
        /// </summary>
        /// <param name="Filename">Полный путь к файлу</param>
        /// <returns>Оценка успешности операции</returns>
        public bool Load(string Filename)
        {
            if (File.Exists(Filename) == false) { return false; }

            try
            {
                FileInfo fi = new FileInfo(Filename);
                if (fi.Length > MAX_FILE_SIZE) { return false; }

                Clear();

                int buf_size = 0;

                switch (dataType)
                {
                    case DataTypes.XProto:

                        buf_size = MAX_DATA_PER_PAGE;
                        break;

                    default:

                        buf_size = 256;
                        break;
                }

                byte[] buffer = new byte[buf_size];

                using (FileStream fs = new FileStream(Filename, FileMode.Open, FileAccess.Read))
                {
                    int bytesRead;
                    // Читаем, пока метод Read возвращает количество байт больше 0
                    while ((bytesRead = fs.Read(buffer, 0, buffer.Length)) > 0)
                    {
                        // Если последняя порция меньше 249, копируем только реально прочитанные байты
                        List<byte> currentChunk = new List<byte>(buffer.Take(bytesRead));

                        if (Add(currentChunk.ToArray()) == false) { break; }
                    }

                    fs.Close();
                }

                return IsValid(false);
            }
            catch { }

            return false;
        }
        // ----------------------------------------------------------------------------------------
        /// <summary>
        /// Получение полной страницы (256) по протоколу Flash/X
        /// </summary>
        /// <param name="Index">Индекс страницы</param>
        /// <returns>Байтовое представление страницы (256 байт) или null</returns>
        public byte[] GetProtoPage(UInt16 Index)
        {
            if (file_data.ContainsKey(Index) == false) { return null; }

            int last_page_idx = MaxPageIndex;

            byte[] page_data = file_data[Index].ToArray();
            if (Utils.ArrayIsNullOrEmpty(page_data)) { return null; }
            
            List<byte> result = new List<byte>();

            if (dataType == DataTypes.XProto)
            {
                ProtoHelper.SectorPageT page = new ProtoHelper.SectorPageT();
                page.STATUS = (Index == last_page_idx) ? ProtoHelper.SECTOR_STATUS_LAST_USABLE : ProtoHelper.SECTOR_STATUS_USABLE;
                page.ID = file_id;
                page.SEGMENT = (UInt16)Index;
                page.LENGTH = (byte)page_data.Length;

                page.CRC8 = CRC8_Class.crc8_calculate(page_data, (byte)page_data.Length);

                byte[] header_data = XProtoSerializer.StructureToBytes(page);
                if (Utils.ArrayIsNullOrEmpty(header_data)) { return null; }

                result.AddRange(header_data);
                result.AddRange(page_data);
            }

            if (dataType == DataTypes.Binary)
            {
                if (expandPages)
                {
                    result = Utils.TailedArray2(page_data, tileCode, 256);
                }
                else
                {
                    result.AddRange(page_data);
                }
            }

            return result.ToArray();
        }
        // ----------------------------------------------------------------------------------------
        /// <summary>
        /// Получение информации о файле в непрерывной области
        /// </summary>
        /// <returns>Информация о файле (кроме адреса)</returns>
        public ProtoHelper.FileRecordT GetInfo()
        {
            ProtoHelper.FileRecordT result = new ProtoHelper.FileRecordT();

            result.ID = file_id;
            result.Size = GetFileLength();
            result.Blocks = (UInt16)Count;
            result.Address = 0;

            return result;
        }
        // ----------------------------------------------------------------------------------------
        /// <summary>
        /// Получение массива байтов структуры информации о файле
        /// </summary>
        /// <param name="Address">Адрес: номер первой страницы во флеше</param>
        /// <returns>Байтовый массив информации о файле</returns>
        public byte[] GetInfo(UInt32 Address)
        {
            ProtoHelper.FileRecordT result = GetInfo();
            result.Address = Address;

            return XProtoSerializer.StructureToBytes(result);
        }
        // ----------------------------------------------------------------------------------------
        /// <summary>
        /// Интерфейс IDisposable
        /// </summary>
        public void Dispose()
        {
            Clear();
            file_data = null;

            GC.SuppressFinalize(this);
        }
        // ----------------------------------------------------------------------------------------
    }
    // --------------------------------------------------------------------------------------------
}
