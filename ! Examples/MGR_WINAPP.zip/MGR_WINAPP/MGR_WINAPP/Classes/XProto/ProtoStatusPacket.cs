﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TEST.COMport_Work1
{
    // --------------------------------------------------------------------------------------------
    /// <summary>
    /// Класс, представляющий статусный пакет
    /// </summary>
    public class ProtoStatusPacket
    {
        protected ProtoStatusPacket() { }

        /// <summary>
        /// Конструктор класса по умолчанию
        /// </summary>
        /// <param name="pack_ident">Идентификатор status пакета</param>
        public ProtoStatusPacket(UInt16 pack_ident)
        {
            _header = new ProtoHelper.ProtoHeader();
            _header.MagicByte = ProtoHelper.UART_PROTO_MAGICBYTE;
            _pack_ident = pack_ident;

            _target.PackIdent = ProtoTargets.XP_STATUS_PACKET;
        }

        public ProtoStatusPacket(UInt16 pack_ident, byte device) : this(pack_ident)
        {
            _target.Device = device;
        }

        public ProtoStatusPacket(UInt16 pack_ident, byte device, byte status_code) : this(pack_ident, device)
        {
            _status_code = status_code;
        }

        private ProtoHelper.ProtoHeader _header;

        /// <summary>
        /// Доступ к заголовку XProto пакета
        /// </summary>
        public ProtoHelper.ProtoHeader Header { get { return _header; } }

        private UInt16 _pack_ident = 0;

        /// <summary>
        /// Идентификатор пакета
        /// </summary>
        public UInt16 Pack_Ident { get { return _pack_ident; } set { _pack_ident = value; } }

        private ProtoTargets.ProtoTarget _target = new ProtoTargets.ProtoTarget();

        /// <summary>
        /// Назначение пакета: устройство
        /// </summary>
        public byte TargetDevice 
        {
            get { return _target.Device; }
            set { _target.Device = value; }
        }

        private List<byte> _data = new List<byte>();

        private byte _status_code = 200;

        public byte StatusCode { get { return _status_code; } set { _status_code = value; } }

        public UInt16 Count { get { return (UInt16)_data.Count; } }

        public void Clear() { _data.Clear(); }

        public string Create()
        {
            _data.Clear();
            _data.Add(_status_code);

            return ProtoHelper.uart_createBinDataPacketStr(_data.ToArray(), _pack_ident, _target, out _header);
        }
    }
    // --------------------------------------------------------------------------------------------
}
