﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TEST.COMport_Work1
{
    // ------------------------------------------------------------------------
    /// <summary>
    /// Константы целей для пакетов X-Proto
    /// </summary>
    public static class ProtoTargets
    {
        // --------------------------------------------------------------------
        // Цели полностью зависят от текущего проекта
        // --------------------------------------------------------------------
        /// <summary>
        /// Идентификатор тестового пакета
        /// </summary>
        public const byte XP_DATA_TEST_PACKET = 0x00;
        // --------------------------------------------------------------------
        // Идентификатор пакета бинарных данных
        public const byte XP_BINDATA_PACKET = 0x01;
        // --------------------------------------------------------------------
        // Идентификатор пакета статуса
        public const byte XP_STATUS_PACKET = 0x02;
        // --------------------------------------------------------------------
        // Идентификатор пакета с командой
        public const byte XP_CMD_PACKET = 0x03;
        // --------------------------------------------------------------------
        // Идентификатор пакета запроса на чтение данных
        public const byte XP_BINDATA_READ_PACKET = 0x04;
        // --------------------------------------------------------------------
        // Идентификатор пакета запроса на запись данных
        public const byte XP_BINDATA_WRITE_PACKET = 0x05;
        // --------------------------------------------------------------------
        // Идентификатор пакета с данными файла
        public const byte XP_FLASHPAGE_READ_PACKET = 0x06;
        // --------------------------------------------------------------------
        // Идентификатор пакета с данными файла
        public const byte XP_FLASHPAGE_WRITE_PACKET = 0x07;
        // --------------------------------------------------------------------
        // Идентификатор пакета с данными файла
        public const byte XP_FLASHPAGE_CONTWRITE_PACKET = 0x08;
        // --------------------------------------------------------------------
        // Константы
        // --------------------------------------------------------------------
        /// <summary>
        /// Максимальный размер пакета XP_BINDATA_PACKET без заголовка
        /// </summary>
        public const UInt16 XP_MAX_BINARY_SIZE = 256;
        // --------------------------------------------------------------------
        // Структура байта Target
        // 76543210
        // DDDDPPPP
        public struct ProtoTarget
        {
            public byte Device;
            public byte PackIdent;
        }
        // --------------------------------------------------------------------
        /// <summary>
        /// Создание байта Target из номера устройства и идентификатор протокола
        /// </summary>
        /// <param name="DeviceID">ID устройства</param>
        /// <param name="PackIdent">ID протокола</param>
        /// <returns>Байт Target</returns>
        public static byte uart_createTarget(byte DeviceID, byte PackIdent)
        {
            return (byte)(((DeviceID & 0x0F) << 4) | (PackIdent & 0x0F));
        }
        // --------------------------------------------------------------------
        /// <summary>
        /// Альтернативный метод создания Target
        /// </summary>
        /// <param name="Target">Объект</param>
        /// <returns>Байт Target</returns>
        public static byte uart_createTarget2(ProtoTarget Target)
        {
            return uart_createTarget(Target.Device, Target.PackIdent);
        }
        // --------------------------------------------------------------------
        /// <summary>
        /// Декодирование байта Target в идентификаторы протокола и устройства
        /// </summary>
        /// <param name="Value">Байт Target из заголовка протокола</param>
        /// <returns>Декодированный заголовок</returns>
        public static ProtoTarget uart_decodeTarget(byte Value)
        {
            ProtoTarget result;

            result.PackIdent = (byte)(Value & 0x0F);
            result.Device = (byte)((Value & 0xF0) >> 4);

            return result;
        }
        // --------------------------------------------------------------------
    }
    // ------------------------------------------------------------------------
}
