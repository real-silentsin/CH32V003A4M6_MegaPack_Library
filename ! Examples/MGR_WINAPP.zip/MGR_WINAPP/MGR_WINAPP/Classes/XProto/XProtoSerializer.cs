﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

namespace TEST.COMport_Work1
{
    public static class XProtoSerializer
    {

        // Превращаем любую структуру в массив байт (Raw)
        public static byte[] StructureToBytes(object str)
        {
            int size = Marshal.SizeOf(str);
            byte[] arr = new byte[size];
            IntPtr ptr = Marshal.AllocHGlobal(size);
            try
            {
                Marshal.StructureToPtr(str, ptr, false);
                Marshal.Copy(ptr, arr, 0, size);
                return arr;
            }
            finally
            {
                Marshal.FreeHGlobal(ptr);
            }
        }

        // Заполняем структуру из массива байт
        public static T BytesToStructure<T>(byte[] data) where T : struct
        {
            T str = new T();
            int size = Marshal.SizeOf(typeof(T));
            IntPtr ptr = Marshal.AllocHGlobal(size);
            try
            {
                // чтобы хвост был чистым, если data.Length < size
                byte[] zeroFiller = new byte[size];
                Marshal.Copy(zeroFiller, 0, ptr, size);

                Marshal.Copy(data, 0, ptr, Math.Min(data.Length, size));
                str = (T)Marshal.PtrToStructure(ptr, typeof(T));
            }
            finally
            {
                Marshal.FreeHGlobal(ptr);
            }
            return str;
        }

        // Сериализация структуры PacketT
        public static byte[] Serialize_PacketT(ProtoHelper.PacketT packet, UInt16 Length)
        {
            if (packet.Data == null || packet.Data.Length < Length) { return null; }

            List<byte> result = new List<byte>();
            byte[] ident = BitConverter.GetBytes(packet.HeaderU32);
            result.AddRange(ident);

            result.AddRange(Utils.TruncateArray(packet.Data, Length));

            return result.ToArray();
        }

        public static List<ProtoHelper.FileRecordT> ParseFileInfo(byte[] data)
        {
            List<ProtoHelper.FileRecordT> result = new List<ProtoHelper.FileRecordT>();
            int structSize = Marshal.SizeOf(typeof(ProtoHelper.FileRecordT));
            int count = data.Length / structSize;

            GCHandle handle = GCHandle.Alloc(data, GCHandleType.Pinned);
            try
            {
                IntPtr currentPtr = handle.AddrOfPinnedObject();

                for (int i = 0; i < count; i++)
                {
                    // Извлекаем структуру по текущему адресу
                    ProtoHelper.FileRecordT info = (ProtoHelper.FileRecordT)Marshal.PtrToStructure(currentPtr, typeof(ProtoHelper.FileRecordT));

                    // Если ID == 0, значит список кончился (или встретили пустышку)
                    //if (info.ID == 0) break;

                    result.Add(info);

                    // Сдвигаем указатель на размер ОДНОЙ структуры для следующей итерации
                    // В .NET 4.0 IntPtr не поддерживает оператор +, используем конструктор
                    currentPtr = new IntPtr(currentPtr.ToInt64() + structSize);
                }
            }
            finally
            {
                handle.Free();
            }


            return result;
        }
    }
}
