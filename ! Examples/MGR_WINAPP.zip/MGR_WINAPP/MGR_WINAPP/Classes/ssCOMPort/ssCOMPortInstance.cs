﻿
namespace ssCOMPort
{
    // ----------------------------------------------------------------------------------------------------------------
    /// <summary>
    /// Класс, представляющий собой образ COM порта
    /// </summary>
    public sealed class ssCOMPortInstance
    {
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Конструктор класса
        /// </summary>
        private ssCOMPortInstance() { }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Конструктор класса
        /// </summary>
        /// <param name="PortName">Имя порта</param>
        public ssCOMPortInstance(string PortName)
        {
            this.portName = PortName;
        }
        // ------------------------------------------------------------------------------------------------------------
        private string portName;
        /// <summary>
        /// Имя порта
        /// </summary>
        public string PortName { get { return portName; } }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Простое имя порта
        /// </summary>
        public string SimplePortName
        {
            get
            {
                if (this.portName.Contains("(COM"))
                {
                    int indexOfCom = this.portName.IndexOf("(COM");

                    return this.portName.Substring(indexOfCom + 1, this.portName.Length - indexOfCom - 2);
                }

                return null;
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        private bool isUSB = false;
        /// <summary>
        /// Флаг возможной принадлежности порта к USB
        /// </summary>
        public bool IsUSB
        {
            get { return isUSB; }
            set { isUSB = value; }
        }
        // ------------------------------------------------------------------------------------------------------------
        private string status = "FAIL";
        /// <summary>
        /// Состояние порта
        /// </summary>
        public string Status
        {
            get { return status; }
            set { status = value; }
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Вывод объекта в строку
        /// </summary>
        /// <returns>Строка, представляющая объект</returns>
        public override string ToString() { return portName; }
        // ------------------------------------------------------------------------------------------------------------
    }
    // ----------------------------------------------------------------------------------------------------------------
}
