﻿using System.Collections;
using System.Collections.Generic;
using System.Management;

namespace ssCOMPort
{
    // ----------------------------------------------------------------------------------------------------------------
    /// <summary>
    /// Класс для получения списка доступных в системе COM портов
    /// </summary>
    public class ssCOMPortList : IEnumerable<ssCOMPortInstance>
    {
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Конструктор класса по умолчанию
        /// </summary>
        public ssCOMPortList() { }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Хранилище портов
        /// </summary>
        private List<ssCOMPortInstance> _portInstances = new List<ssCOMPortInstance>();
        // ------------------------------------------------------------------------------------------------------------
        private bool includeHardwarePorts = true;
        /// <summary>
        /// Флаг сканирования аппаратных (не USB) портов системы
        /// </summary>
        public bool IncludeHardwarePorts
        {
            get { return this.includeHardwarePorts; }
            set { this.includeHardwarePorts = value; }
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Доступ к портам по индексу
        /// </summary>
        /// <param name="Index">Валидный, в пределах списка, индекс порта</param>
        /// <returns>Ссылка на порт или null</returns>
        public ssCOMPortInstance this[int Index]
        {
            get
            {
                return (Index < _portInstances.Count) ? _portInstances[Index] : null;
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Количество обнаруженных портов системы
        /// </summary>
        public int Count { get { return _portInstances.Count; } }
        // ------------------------------------------------------------------------------------------------------------
        // Обновление списка портов системы
        public void Refresh()
        {
            _portInstances.Clear();

            try
            {
                ManagementObjectSearcher searcher = new ManagementObjectSearcher("root\\CIMV2",
                    "SELECT * FROM Win32_PnPEntity WHERE ClassGuid=\"{4d36e978-e325-11ce-bfc1-08002be10318}\"");

                foreach (ManagementObject queryObj in searcher.Get())
                {
                    try
                    {
                        string _pName = (string)queryObj["Name"];

                        if (false == string.IsNullOrEmpty(_pName))
                        {
                            ssCOMPortInstance newPort = new ssCOMPortInstance(_pName);

                            newPort.Status = queryObj["Status"].ToString();

                            if (queryObj["DeviceID"].ToString().Contains("USB"))
                            {
                                newPort.IsUSB = true;
                            }

                            if (includeHardwarePorts || newPort.IsUSB)
                            {
                                _portInstances.Add(newPort);
                            }
                        }
                    }
                    catch { }
                }
            }
            catch { }
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Получение списка портов системы
        /// </summary>
        /// <returns>Список портов системы</returns>
        public IEnumerator<ssCOMPortInstance> GetEnumerator()
        {
            foreach (ssCOMPortInstance port in _portInstances)
            {
                yield return port;
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Получение списка портов системы
        /// </summary>
        /// <returns>Список портов системы</returns>
        IEnumerator IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }
        // ------------------------------------------------------------------------------------------------------------
    }
}
