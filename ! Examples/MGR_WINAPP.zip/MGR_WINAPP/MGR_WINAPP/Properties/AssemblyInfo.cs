﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("MEGAPACK Controller")]
[assembly: AssemblyDescription("Serial Controller for Test Application")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Vantr Universal Co. Ltd")]
[assembly: AssemblyProduct("MGR_WINAPP")]
[assembly: AssemblyCopyright("© 2026 vantr")]
[assembly: AssemblyTrademark("MEGAPACK")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("9c6db49e-8110-4f3a-ab4c-e715835711ae")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers 
// by using the '*' as shown below:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.06.07.26")]
[assembly: AssemblyFileVersion("1.0.4.1")]
