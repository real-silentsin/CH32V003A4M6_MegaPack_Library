﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.ComponentModel;

namespace TEST.COMport_Work1
{
    // ----------------------------------------------------------------------------------------------------------------
    /// <summary>
    /// Статический класс утилит
    /// </summary>
    public static class Utils
    {
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// получаем имя из связки "имя[delimiter]значение"
        /// </summary>
        /// <param name="Str">исходная строка</param>
        /// <param name="Delimiter">разделяющий символ</param>
        /// <returns>имя строки</returns>
        public static string GetName(string Str, char Delimiter)
        {
            if (string.IsNullOrEmpty(Str)) return string.Empty;

            int ind = Str.IndexOf(Delimiter);
            if (ind > -1) return Str.Substring(0, ind); else return Str;
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// получаем значение из связки "имя[delimiter]значение"
        /// </summary>
        /// <param name="Str">исходная строка</param>
        /// <param name="Delimiter">разделяющий символ</param>
        /// <returns>значение строки</returns>
        public static string GetValue(string Str, char Delimiter)
        {
            if (string.IsNullOrEmpty(Str)) return string.Empty;

            int ind = Str.IndexOf(Delimiter);
            if (ind > -1) return Str.Substring(ind + 1); else return string.Empty;
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Проверка, является ли байтовый массив пустым или неопределенным
        /// </summary>
        /// <param name="Value">Проверяемый байтовый массив</param>
        /// <returns>True - массив есть null или пуст</returns>
        public static bool ArrayIsNullOrEmpty<TSource>(ICollection<TSource> Value)
        {
            return (Value == null || Value.Count == 0);
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Проверка, является ли байтовый массив пустым или неопределенным
        /// </summary>
        /// <param name="Value">Проверяемый байтовый массив</param>
        /// <returns>True - массив есть null или пуст</returns>
        public static bool ArrayIsNullOrEmpty<TSource>(IEnumerable<TSource> Value)
        {
            return (Value == null || Value.Count() == 0);
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Добавление массива байтов в конец указанного массива байтов (объединение)
        /// </summary>
        /// <param name="Data">Исходный массив байтов</param>
        /// <param name="Addon">Добавляемый массив байтов</param>
        /// <returns>Объединенный массив или null</returns>
        public static byte[] ArrayAddArray(byte[] Data, byte[] Addon)
        {
            if (ArrayIsNullOrEmpty(Data)) { return null; }
            if (ArrayIsNullOrEmpty(Addon)) { return Data; }

            List<byte> result = new List<byte>(Data);
            result.AddRange(Addon);

            return result.ToArray<byte>();
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Метод поддержки конвертирования HEX -> DEC
        /// </summary>
        /// <param name="b"></param>
        /// <returns></returns>
        private static int ToInt(byte b)
        {
            return b >= 65 ? (b & 0xDF) - 65 + 10 : b - 48;
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Конвертирование данных HEX в байтовое значение
        /// </summary>
        /// <param name="H1">Байт, содержащий первый символ</param>
        /// <param name="H2">Байт, содержащий второй символ</param>
        /// <returns>Десятичный результат</returns>
        public static byte HexToByte(byte H1, byte H2)
        {
            return (byte)((ToInt(H1) << 4) | ToInt(H2));
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Конвертирование 4-х HEX символов в 16-битное число
        /// </summary>
        /// <param name="h1">Старший полубайт первого байта (High)</param>
        /// <param name="h2">Младший полубайт первого байта</param>
        /// <param name="h3">Старший полубайт второго байта (Low)</param>
        /// <param name="h4">Младший полубайт второго байта</param>
        /// <returns>UInt16 результат</returns>
        public static ushort HexToUInt16(byte h1, byte h2, byte h3, byte h4)
        {
            // Собираем два байта и склеиваем их в ushort
            // Обычно в HEX-строках данные идут как [MSB, LSB]
            return (ushort)((HexToByte(h1, h2) << 8) | HexToByte(h3, h4));
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Усечение массива до указанного размера
        /// </summary>
        /// <param name="source">Исходный массив</param>
        /// <param name="newSize">Новый размер (меньше исходного)</param>
        /// <returns>Массив указанного размера</returns>
        public static byte[] TruncateArray(byte[] source, int newSize)
        {
            if (ArrayIsNullOrEmpty(source)) { return new byte[0]; }
            // Если массив уже нужного размера или меньше — возвращаем как есть
            if (source.Length <= newSize) return source;

            // Создаем новый "короткий" массив
            byte[] dest = new byte[newSize];

            // Копируем только первые newSize байт
            Array.Copy(source, 0, dest, 0, newSize);

            return dest;
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Получение массива, заполненного указанным значением
        /// </summary>
        /// <param name="value">Значение, которым заполняют массив</param>
        /// <param name="arraySize">Размер массива</param>
        /// <returns>Заполненный указанным значением массив указанной длины</returns>
        public static byte[] FilledArray(byte value, int arraySize)
        {
            return Enumerable.Repeat((byte)value, arraySize).ToArray();
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Создание массива указанного размера, дополненного указанным значением, если размер меньше требуемого
        /// </summary>
        /// <param name="source">Исходный массив (может быть пустым или null)</param>
        /// <param name="tileValue">Значение, которым дополняют массив</param>
        /// <param name="arraySize">Окончательный размер массива</param>
        /// <returns>Заполненный массив указанной длины</returns>
        public static byte[] TailedArray(byte[] source, byte tileValue, int arraySize)
        {
            // --------------------------------------------------------------------------------------------------------
            // 1. Сразу выделяем массив нужного результирующего размера
            byte[] result = new byte[arraySize];

            int sourceLength = 0;

            // 2. Если исходный массив не пустой, копируем из него столько, сколько поместится
            if (source != null && source.Length > 0)
            {
                // Берем либо длину исходного, либо arraySize, если исходный массив длиннее целевого
                sourceLength = Math.Min(source.Length, arraySize);
                Array.Copy(source, 0, result, 0, sourceLength);
            }

            // 3. Заполняем оставшуюся часть массива (хвост) указанным значением
            for (int i = sourceLength; i < arraySize; i++)
            {
                result[i] = tileValue;
            }

            return result;
            // --------------------------------------------------------------------------------------------------------
            /*List<byte> result = new List<byte>();

            if (Utils.ArrayIsNullOrEmpty(source) == false && source.Length > 0)
            {
                result.AddRange(source);
            }

            result.AddRange(FilledArray(tileValue, arraySize));

            return TruncateArray(result.ToArray(), arraySize); */
            // --------------------------------------------------------------------------------------------------------
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Создание массива указанного размера, дополненного указанным значением, если размер меньше требуемого
        /// </summary>
        /// <param name="source">Исходный массив (может быть пустым или null)</param>
        /// <param name="tileValue">Значение, которым дополняют массив</param>
        /// <param name="arraySize">Окончательный размер массива</param>
        /// <returns>Заполненный массив указанной длины</returns>
        public static List<byte> TailedArray2(byte[] source, byte tileValue, int arraySize)
        {
            // --------------------------------------------------------------------------------------------------------
            // 1. Сразу выделяем массив нужного результирующего размера
            byte[] result = new byte[arraySize];

            int sourceLength = 0;

            // 2. Если исходный массив не пустой, копируем из него столько, сколько поместится
            if (source != null && source.Length > 0)
            {
                // Берем либо длину исходного, либо arraySize, если исходный массив длиннее целевого
                sourceLength = Math.Min(source.Length, arraySize);
                Array.Copy(source, 0, result, 0, sourceLength);
            }

            // 3. Заполняем оставшуюся часть массива (хвост) указанным значением
            for (int i = sourceLength; i < arraySize; i++)
            {
                result[i] = tileValue;
            }

            return new List<byte>(result);
            // --------------------------------------------------------------------------------------------------------
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Сравнение двух строк с/или без учета регистра
        /// </summary>
        /// <param name="Value1">Строка 1</param>
        /// <param name="Value2">Строка 2</param>
        /// <param name="CaseSensitive">true - регистр учитывается</param>
        /// <returns>
        /// меньше нуля - Value1 больше Value2, больше нуля - Value1 меньше Value2, равен нулю  - строки равны
        /// </returns>
        public static int StringCompare(string Value1, string Value2, bool CaseSensitive)
        {
            if (string.IsNullOrEmpty(Value1) && string.IsNullOrEmpty(Value2)) { return 0; }
            if (string.IsNullOrEmpty(Value1)) { return 1; }
            if (string.IsNullOrEmpty(Value2)) { return -1; }

            CompareInfo ci = new CultureInfo("").CompareInfo;
            if (!CaseSensitive) { return ci.Compare(Value1, Value2, CompareOptions.IgnoreCase); }
            else { return ci.Compare(Value1, Value2); }
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Декодирование списка UINT16, передаваемых в бинарном виде
        /// </summary>
        /// <param name="Data">Массив байтов</param>
        /// <returns>Массив 16-битных значений</returns>
        public static UInt16[] DecodeUINT16List(byte[] Data)
        {
            if (ArrayIsNullOrEmpty(Data)) { return null; }

            List<UInt16> result = new List<ushort>();

            for (int index = 0; index < Data.Length / 2; index++)
            {
                UInt16 val_t = (UInt16)BitConverter.ToInt16(Data, index * 2);
                result.Add(val_t);
            }

            return result.ToArray();
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Дописать в указанный файл двоичную информацию
        /// </summary>
        /// <param name="filename">Полный путь к файлу</param>
        /// <param name="data">Дописываемые данные</param>
        public static void FileAppendBytes(string filename, byte[] data)
        {
            if (string.IsNullOrEmpty(filename)) { return; }
            if (ArrayIsNullOrEmpty(data)) { return; }

            // FileMode.Append сам переместит указатель в конец файла
            using (var fs = new System.IO.FileStream(filename, FileMode.Append, FileAccess.Write, FileShare.ReadWrite))
            {
                fs.Write(data, 0, data.Length);
                //fs.Close();
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Конвертирование байтов в 16-битное целое
        /// </summary>
        /// <param name="p1">Старший байт</param>
        /// <param name="p2">Младший байт</param>
        /// <returns>Целое 16-битное</returns>
        public static UInt16 BytesToUint16(byte p1, byte p2)
        {
            return (UInt16)((p2 << 8) | p1);
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Получение строки описания из указаного элемента перечисления
        /// </summary>
        /// <param name="value">Перечисление,для которого ищется описание</param>
        /// <returns>Строка описания</returns>
        public static string GetDescription(Enum value)
        {
            try
            {
                // 1. Получаем тип перечисления
                Type type = value.GetType();

                // 2. Получаем информацию о конкретном поле перечисления по его имени
                FieldInfo fieldInfo = type.GetField(value.ToString());

                // 3. Ищем атрибут DescriptionAttribute у этого поля
                DescriptionAttribute[] attributes = (DescriptionAttribute[])fieldInfo.GetCustomAttributes(
                    typeof(DescriptionAttribute), false);

                // 4. Если атрибут найден — возвращаем текст, иначе — просто имя константы
                if (attributes != null && attributes.Length > 0)
                {
                    return attributes[0].Description;
                }
                else
                {
                    return value.ToString();
                }
            }
            catch { }

            return value.ToString();;
        }
        // ------------------------------------------------------------------------------------------------------------
    }
    // ----------------------------------------------------------------------------------------------------------------
}
